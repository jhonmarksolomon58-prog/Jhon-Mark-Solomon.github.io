import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/**
 * AssignmentReport
 * -----------------
 * Reads data/assignments.json (written by the PHP storage system) and
 * produces a compact summary report: totals, per-course counts, and
 * per-student submission counts. No external JSON library is used —
 * a small hand-rolled parser keeps this self-contained and dependency-free.
 *
 * Usage: java AssignmentReport <path-to-assignments.json>
 */
public class AssignmentReport {

    record Assignment(String studentName, String studentId, String course,
                       String title, String originalName, long size, String submittedAt) {}

    public static void main(String[] args) throws IOException {
        String path = args.length > 0 ? args[0] : "data/assignments.json";
        String json = new String(Files.readAllBytes(Paths.get(path)));

        List<Assignment> assignments = parseAssignments(json);

        System.out.println("=== Assignment Storage Report ===");
        System.out.println("Total submissions: " + assignments.size());

        Map<String, Integer> byCourse = new TreeMap<>();
        Map<String, Integer> byStudent = new TreeMap<>();
        long totalBytes = 0;

        for (Assignment a : assignments) {
            byCourse.merge(a.course(), 1, Integer::sum);
            byStudent.merge(a.studentName() + " (" + a.studentId() + ")", 1, Integer::sum);
            totalBytes += a.size();
        }

        System.out.println("Total storage used: " + humanSize(totalBytes));

        System.out.println("\n-- By Course --");
        for (var e : byCourse.entrySet()) {
            System.out.printf("  %-30s %d%n", e.getKey(), e.getValue());
        }

        System.out.println("\n-- By Student --");
        for (var e : byStudent.entrySet()) {
            System.out.printf("  %-30s %d%n", e.getKey(), e.getValue());
        }

        System.out.println("\nGenerated " + new Date());
    }

    /** Minimal JSON array-of-objects parser, tailored to the known field set. */
    private static List<Assignment> parseAssignments(String json) {
        List<Assignment> result = new ArrayList<>();
        Pattern objPattern = Pattern.compile("\\{[^{}]*\\}");
        Matcher objMatcher = objPattern.matcher(json);

        while (objMatcher.find()) {
            String obj = objMatcher.group();
            String studentName = field(obj, "student_name");
            String studentId = field(obj, "student_id");
            String course = field(obj, "course");
            String title = field(obj, "title");
            String originalName = field(obj, "original_name");
            String sizeStr = field(obj, "size");
            String submittedAt = field(obj, "submitted_at");

            if (studentName == null) continue; // skip malformed entries

            long size = 0;
            try { size = Long.parseLong(sizeStr); } catch (Exception ignored) {}

            result.add(new Assignment(studentName, studentId, course, title,
                    originalName, size, submittedAt));
        }
        return result;
    }

    private static String field(String obj, String key) {
        Pattern p = Pattern.compile("\"" + key + "\"\\s*:\\s*\"?([^\",}]*)\"?");
        Matcher m = p.matcher(obj);
        return m.find() ? m.group(1).trim() : null;
    }

    private static String humanSize(long bytes) {
        String[] units = {"B", "KB", "MB", "GB"};
        double size = bytes;
        int i = 0;
        while (size >= 1024 && i < units.length - 1) {
            size /= 1024;
            i++;
        }
        return String.format("%.1f %s", size, units[i]);
    }
}
